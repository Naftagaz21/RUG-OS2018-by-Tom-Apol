#ifndef INTERPRETER_H
#define INTERPRETER_H

//returns 0 if successful, returns -1 otherwise.
int interpretSimpleList(Simple_List *list);

#endif
